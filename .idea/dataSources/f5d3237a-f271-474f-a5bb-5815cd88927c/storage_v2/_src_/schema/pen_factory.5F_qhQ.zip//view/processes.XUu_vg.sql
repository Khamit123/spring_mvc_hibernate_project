create definer = root@localhost view processes as
select `pr`.`name`              AS `Название процесса`,
       `pr`.`description`       AS `Описание процесса`,
       `pro`.`name`             AS `Название продукта`,
       `m`.`name`               AS `Название мматериала`,
       `pr`.`material_quantity` AS `Количество материала`,
       `mt`.`name`              AS `Название оборудования`
from ((((`pen_factory`.`process_stage` `p` join `pen_factory`.`process` `pr`
         on ((`p`.`process_id` = `pr`.`process_id`))) join `pen_factory`.`product` `pro`
        on ((`pr`.`product_id` = `pro`.`product_id`))) join `pen_factory`.`material` `m`
       on ((`pr`.`material_id` = `m`.`material_id`))) join `pen_factory`.`machine_type` `mt`
      on ((`p`.`machine_type_id` = `mt`.`machine_type_id`)));

