create definer = root@localhost trigger insertproduct
    before insert
    on product
    for each row
begin
declare a int;
set new.price =productprice(NEW.product_id);
end;

