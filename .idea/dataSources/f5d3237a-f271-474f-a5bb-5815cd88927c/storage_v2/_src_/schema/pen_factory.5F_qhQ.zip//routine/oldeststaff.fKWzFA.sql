create
    definer = root@localhost function oldeststaff() returns varchar(255) deterministic
begin
declare a varchar(255);
select concat('Самый старый сотрудник -',s.last_name,' ',s.name,' ',s.middle_name,', возвраст - ',
((YEAR(CURRENT_DATE)-YEAR(birthday))-(RIGHT(CURRENT_DATE,5)<RIGHT(birthday,5))))
from staff s order by current_date()-birthday desc limit 1 into a;
return a;
end;

