create
    definer = root@localhost procedure process_product(IN pr_id int)
begin
  select concat(p.name,' ',convert_color(p.color)) as "Продукт получаемы в итоге процеса",pe.name as "Название процесса",
  mt.name as "Тип машины",ps.machine_quantity as " Количество машин",m.name as " Название материала",pe.material_quantity as "Количество материала" from product p
  inner join `process` pe using(product_id)
  inner join process_stage  ps using (process_id)
  inner join machine_type mt using(machine_type_id)
  inner join material m using(material_id)
  where p.product_id=pr_id;
end;

