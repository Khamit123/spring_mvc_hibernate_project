create
    definer = root@localhost function bestcustomer() returns int deterministic
begin
declare a int ;
select customer.name ,sum(o.price) from `order` o
inner join customer using(customer_id) group by customer_id order by sum(o.price)  desc limit 1 into a;
return a;
end;

