create definer = root@localhost view machines as
select `m`.`name`                 AS `Название станка`,
       `ma`.`date_of_maintenance` AS `Дата последнего обслуживания`,
       `s`.`name`                 AS `Работник проводивший обслуживание`,
       `ms`.`name`                AS `Статус`,
       `mt`.`name`                AS `Тип`,
       `f`.`name`                 AS `Фабрика на которой находится`
from (((((`pen_factory`.`machinery` `m` join `pen_factory`.`maintenance` `ma`
          on ((`m`.`maintenance_id` = `ma`.`maintenance_id`))) join `pen_factory`.`machine_type` `mt`
         on ((`m`.`machine_type_id` = `mt`.`machine_type_id`))) join `pen_factory`.`machine_status` `ms`
        on ((`m`.`machine_status_id` = `ms`.`machine_status_id`))) join `pen_factory`.`staff` `s`
       on ((`ma`.`staff_id` = `s`.`staff_id`))) join `pen_factory`.`factory` `f`
      on ((`m`.`factory_id` = `f`.`factory_id`)));

