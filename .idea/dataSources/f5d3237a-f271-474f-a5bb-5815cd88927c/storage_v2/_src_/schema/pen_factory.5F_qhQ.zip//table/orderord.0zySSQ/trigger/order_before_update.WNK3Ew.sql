create definer = root@localhost trigger order_before_update
    before update
    on orderord
    for each row
begin
declare a int;
 if old.status!='Выполнен' then set new.date_of_update=curdate();
 end if;
 end;

