create
    definer = root@localhost function factorysalary(id int) returns int deterministic
begin
declare a int ;
select sum(p.price*m.product_quantity) from `order` 
inner join product p using(product_id) 
inner join manufacture m using(product_id) inner join factory f using(factory_id)
where factory_id=id
 group by factory_id 
 order by sum(p.price*m.product_quantity)  into a;
return a;
end;

