create definer = root@localhost trigger updateproduct
    before update
    on product
    for each row
begin
declare a int;
set new.price =productprice(NEW.product_id);
end;

