create
    definer = root@localhost procedure customers()
begin
select c.name,sum(o.price) as Итоговая_сумма from customer c inner join `order` o using(customer_id)
inner join product p using(product_id) group by c.name order by Итоговая_сумма DESC;
 end;

