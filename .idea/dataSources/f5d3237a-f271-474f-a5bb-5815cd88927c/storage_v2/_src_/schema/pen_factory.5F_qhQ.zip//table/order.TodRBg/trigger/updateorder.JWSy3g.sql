create definer = root@localhost trigger updateorder
    before update
    on `order`
    for each row
begin
set new.price =productprice(NEW.product_id)*new.product_quantity;
end;

