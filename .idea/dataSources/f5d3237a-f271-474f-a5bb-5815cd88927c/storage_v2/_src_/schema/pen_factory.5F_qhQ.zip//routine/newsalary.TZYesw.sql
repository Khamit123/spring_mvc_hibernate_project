create
    definer = root@localhost procedure newsalary(IN proc int, IN flag tinyint(1))
begin
 if flag=true then update staff set salary=salary*(1+proc/100);
else update staff set salary=salary*(1-proc/100);
end if;
 end;

