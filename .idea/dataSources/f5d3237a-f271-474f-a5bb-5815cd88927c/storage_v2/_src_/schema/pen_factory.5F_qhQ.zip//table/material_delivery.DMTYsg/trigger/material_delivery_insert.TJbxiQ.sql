create definer = root@localhost trigger material_delivery_insert
    before insert
    on material_delivery
    for each row
begin
declare a int;
set new.price=(select price from material where material_id=New.material_id)*new.material_quantity;
end;

