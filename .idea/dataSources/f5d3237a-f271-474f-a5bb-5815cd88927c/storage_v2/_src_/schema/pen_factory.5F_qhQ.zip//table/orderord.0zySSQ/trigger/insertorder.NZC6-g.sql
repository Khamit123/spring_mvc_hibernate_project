create definer = root@localhost trigger insertorder
    before insert
    on orderord
    for each row
BEGIN
 DECLARE a int; 
 set new.date_of_record=curdate();
 set new.price =productprice(NEW.product_id)*new.product_quantity;
SELECT product_storage.product_quantity INTO a FROM product_storage WHERE NEW.product_id = product_storage.product_id;
 IF a >= NEW.product_quantity
 THEN SET NEW.status ="Ожидание доставки";
 set new.date_of_update=curdate();
 END IF;
 UPDATE product_storage SET product_storage.product_quantity = a-NEW.product_quantity WHERE NEW.product_id = product_storage.product_id;

 
end;

