create
    definer = root@localhost function productprice(product_id1 int) returns int deterministic
begin
declare a int;
select sum(m.price) into a from composition_of_product as c natural join material as m where c.product_id=product_id1 group by product_id;
return a;
end;

